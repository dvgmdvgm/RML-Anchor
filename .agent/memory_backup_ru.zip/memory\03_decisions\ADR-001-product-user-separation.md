# ⚖️ ADR-001: Разделение product/user данных через .gitignore + skip-worktree

- **Создано**: 2026-02-08
- **Статус**: ✅ Принято
- **Теги**: git, deployment, data-separation

---

## Контекст

Разработчик (автор проекта) одновременно является и пользователем RLM-Anchor. При работе над проектом в памяти накапливаются личные записи, сессии, предпочтения. Эти данные не должны попадать на GitHub, т.к. другие пользователи получают чистый шаблон.

## Решение

Двухуровневая защита:

### 1. `.gitignore` — для новых файлов

Все пользовательские файлы (entries, сессии, бэкапы, stats) исключены из git:
```
.agent/memory/01_project/*.md (кроме _index.md)
.agent/memory/07_context/session_history/
.agent/memory/13_preferences/language_local.md
.agent/backups/
```

### 2. `skip-worktree` — для шаблонных файлов

`_index.md` файлы (13 штук) + `current_session.md` + `pending_tasks.md` — трекаются в git как чистые шаблоны, но локальные изменения невидимы.

```bash
git update-index --skip-worktree .agent/memory/01_project/_index.md
# Настройка: bash .agent/scripts/skip_worktree_setup.sh
# Отмена:    bash .agent/scripts/skip_worktree_undo.sh
```

## Альтернативы

| Вариант | Почему отклонён |
|---------|----------------|
| Два remote (private + public) | Сложнее workflow, нужен release-скрипт |
| Ветки (dev + master) | Постоянные merge-конфликты |
| Чистка перед каждым push | Рискованно, можно забыть |

## Последствия

- ✅ `git push` всегда пушит чистый шаблон
- ✅ Пользовательские данные остаются только локально
- ⚠️ Для обновления шаблонов нужно временно снимать skip-worktree
