# 📂 Структура проекта

- **Создано**: 2026-02-08
- **Статус**: ✅ Активен

---

## Корневой каталог

```
AnchorGravity/
├── README.md                    # Главный README (EN)
├── README_RU.md                 # README на русском
├── .gitignore                   # Разделение product/user data
├── docs/
│   └── COMMANDS.md              # Полный справочник команд
├── docs_backup/
│   └── archive/                 # Старая документация (17 файлов)
└── .agent/                      # ← Ядро продукта
```

## Структура .agent/

```
.agent/
├── MEMORY_INDEX.md              # Главный индекс памяти
├── VERSION                      # Версия продукта (2.1.0)
│
├── memory/                      # 13 категорий памяти
│   ├── 01_project/              # Информация о проекте
│   ├── 02_architecture/         # Архитектура
│   ├── 03_decisions/            # ADR (Architecture Decision Records)
│   ├── 04_domain/               # Бизнес-логика
│   ├── 05_code/                 # Код и паттерны
│   ├── 06_problems/             # Проблемы и решения
│   │   ├── bugs/                # Баги
│   │   └── workarounds/         # Обходные пути
│   ├── 07_context/              # Контекст сессий
│   │   ├── session_history/     # Архив сессий (gitignored)
│   │   └── walkthroughs/        # Документация (gitignored)
│   ├── 08_people/               # Люди и роли
│   ├── 09_external/             # Внешние зависимости
│   ├── 10_testing/              # Тестирование
│   ├── 11_deployment/           # Деплой
│   ├── 12_roadmap/              # Планы
│   └── 13_preferences/          # Пользовательские настройки
│       ├── language.md           # Язык (EN по умолчанию)
│       ├── language_local.md     # Локальный override (gitignored)
│       ├── coding_style.md       # Стиль кода
│       ├── communication.md      # Стиль общения
│       └── ...
│
├── workflows/                   # 15 workflow-инструкций (команды)
│   ├── wakeup.md                # /wakeup
│   ├── sleep.md                 # /sleep
│   ├── remember.md              # /remember
│   ├── recall.md                # /recall
│   ├── handoff.md               # /handoff
│   ├── walkthrough.md           # /walkthrough
│   ├── anchor_agent.md          # /anchor_agent
│   ├── anchor_update.md         # /anchor_update
│   ├── anchor_backup.md         # /anchor_backup
│   ├── anchor_restore.md        # /anchor_restore
│   ├── anchor_cleanup.md        # /anchor_cleanup
│   ├── anchor_validate.md       # /anchor_validate
│   ├── anchor_briefing.md       # /anchor_briefing
│   ├── anchor_remove.md         # /anchor_remove
│   └── memory-stats.md          # /memory-stats
│
├── scripts/                     # Python + Bash утилиты
│   ├── memory_search.py         # Поиск по памяти
│   ├── memory_stats.py          # Статистика
│   ├── memory_validate.py       # Валидация структуры
│   ├── skip_worktree_setup.sh   # Настройка git skip-worktree
│   └── skip_worktree_undo.sh    # Отмена skip-worktree
│
└── skills/
    └── MEMORY_SKILL.md          # Главная инструкция для AI
```

## Ключевые соглашения

- **Каждая категория** содержит `_index.md` — индекс файлов
- **_template.md** — шаблоны для ADR и проблем
- **language_local.md** — локальный override языка (gitignored)
- **Файлы именуются** в kebab-case: `tech-stack.md`
- **Решения** именуются: `ADR-NNN-topic.md`
- **Проблемы** именуются: `PROB-NNN-topic.md`
