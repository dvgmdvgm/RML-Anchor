# 🏗️ PROJECT — General Project Information

> **Category**: 01_project  
> **Last Updated**: —

---

## 📋 Category Description

This category contains general project information:
- Project description and goals
- Technology stack
- File/folder structure
- Dependencies and requirements

---

## 📁 Files in This Category

| File | Description | Updated |
|------|-------------|---------|
| `overview.md` | Обзор проекта, назначение, возможности | 2026-02-08 |
| `techstack.md` | Технологический стек (Markdown, Python, Bash) | 2026-02-08 |
| `structure.md` | Структура каталогов проекта | 2026-02-08 |

---

## 🔍 When to Access This Category

- "What tech stack?"
- "What is this project?"
- "What's the project structure?"
- "What dependencies are used?"
- "What is the project for?"

---

## ➕ How to Add Entry

1. Create file in format `topic-name.md`
2. Use template from `_template.md`
3. Update this table
Modified by user
