# 🏛️ Архитектурные паттерны RLM-Anchor

- **Создано**: 2026-02-08
- **Статус**: ✅ Активен

---

## Основной паттерн: RLM (Recursive Language Model)

Система построена на принципе рекурсивного поиска из MIT research:

```
1. EXAMINE   → Прочитать главный индекс MEMORY_INDEX.md
2. DECOMPOSE → Определить релевантные категории (2-3 из 13)
3. RECURSE   → Прочитать _index.md категорий → найти файлы → прочитать содержимое
4. AGGREGATE → Объединить найденную информацию в ответ
```

## Архитектура хранения

**Flat-file Markdown** — без базы данных, без сервера:
- Каждая запись = один `.md` файл
- Индексы = таблицы в `_index.md`
- Поиск = текстовый (grep-like)
- Версионирование = Git

## Паттерн Command (Workflows)

Каждая команда (`/wakeup`, `/sleep`, etc.) — это Markdown-файл с инструкциями для AI:
- Файл содержит **пошаговый алгоритм**
- AI читает и выполняет шаги последовательно
- Формат: человекочитаемый, не код

## Паттерн Observer (Triggers)

`MEMORY_SKILL.md` определяет trigger-слова:
- AI наблюдает за запросами пользователя
- При обнаружении trigger'а — обращается к памяти
- Пример: «почему мы выбрали...» → категория `03_decisions`

## Паттерн Template Method

- `_index.md` — единый формат для всех 13 категорий
- `_template.md` — шаблоны для ADR и проблем
- Новые записи создаются по шаблону

## Разделение данных (Product vs User)

```
Product (в git):           User (только локально):
─────────────────          ──────────────────────
workflows/*.md             memory entries (ADR-*.md)
scripts/*.py               session_history/
skills/*.md                walkthroughs/
_index.md (шаблоны)        _index.md (заполненные)
language.md                language_local.md
coding_style.md            backups/
```

Реализовано через `.gitignore` + `git update-index --skip-worktree`.
